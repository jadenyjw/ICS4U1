
/*************************************************************
Name: Jaden Wang
Course: ICS4U1
Date: February 8, 2017
Teacher: Ms. Strelkovska
Assignment: GUI Assignments
*************************************************************/
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;
public class Main{
  public static void main(String[] args){

    Q1 q1 = new Q1();

    Q2 q2 = new Q2();

    Q3 q3 = new Q3();

    Q4 q4 = new Q4();

  }
}
