/*************************************************************
Name: Jaden Wang
Course: ICS4U1
Date: February 7, 2017
Teacher: Ms. Strelkovska
Assignment: Question 1
*************************************************************/

public class E1{

  public static void main (String[] args){

  }

  private static boolean isSquare(int n){

    if (Math.sqrt(n) % 1 == 0){
      return true;
    }
    else{
      return false;
    }

  }

}
