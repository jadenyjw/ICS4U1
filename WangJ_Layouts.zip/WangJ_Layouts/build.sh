javac *.java
java Main
