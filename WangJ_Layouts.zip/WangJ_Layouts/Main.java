/*************************************************************
Name: Jaden Wang
Course: ICS4U1
Date: February 8, 2017
Teacher: Ms. Strelkovska
Assignment: Layout Assignments
*************************************************************/
public class Main{
  public static void main(String[] args){


    Q2 q2 = new Q2();

    Q3 q3 = new Q3();

    Q4 q4 = new Q4();

    Q5 q5 = new Q5();
  }
}
