public static class Deck{

  public Deck(){
    
  }

}
